//
// Created by Thinkpad on 2019/6/30.
//

#include <stdio.h>
#include <time.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "uno.h"
#define JACK 11
#define QUEEN 12
#define KING 13
#define ACE 14

int who_wins(create *member){
    for(int i=0;i<20;i++){
        if(member->hand[i].num >= 2 && member->hand[i].num <= 14){
            return 0;
        }
    }
    system("cls");
    printf("%s WINS!! CONGRATULATIONS!!\n",member->name);
    return 1;
}