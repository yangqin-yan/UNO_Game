//
// Created by Thinkpad on 2019/6/30.
//

#include <stdio.h>
#include <time.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "uno.h"

void create_member(int num_player,create *head,create *member){
    create *node;
    member = calloc(num_player , sizeof(create));
    for(int i=0;i<num_player;i++){
        node = calloc(num_player , sizeof(create));
        //member = malloc(num_player * sizeof(create));
        node->next = NULL;
        node->before = NULL;
        if(head == NULL){
            head = node;
            member = node;
        }
        else{
            member->next = node;
            node->before = member;
            member = member->next;
        }

        printf("Player %d, your name is:",i+1);
        gets(member->name);
        system("cls");
    }
    member->next = head;
    (member->next)->before = member;//closed circle

}