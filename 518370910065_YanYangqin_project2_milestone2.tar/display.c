//
// Created by Thinkpad on 2019/6/24.
//
#include <stdio.h>
#include <time.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "uno.h"

int display(create *member,int hand_position, \
card discard[],int discard_position,int seq){

    //play to the discard
    discard_position++;
    //printf("%d",hand_position);

    discard[discard_position].num = member->hand[hand_position].num;//bug
    strcpy(discard[discard_position].kind,member->hand[hand_position].kind);//bug
    //printf("1\n");
    printf("play:");
    card_print(discard[discard_position]);
    printf("\n");
    printf("\n");
    getchar();

    //delete the card in hand
    for(int i=hand_position;i<MAX_HAND-1;i++){
        member->hand[i].num = member->hand[i+1].num;
        strcpy(member->hand[i].kind,member->hand[i+1].kind);
    }
    //judge the special effect of the card
    if(discard[discard_position].num == 2 && seq == 0){
        (member->next)->situa = 2;
    }
    if(discard[discard_position].num == 2 && seq == 1){
        (member->before)->situa = 2;
    }
    if(discard[discard_position].num == 3 && seq == 0){
        (member->next)->situa = 3;
    }
    if(discard[discard_position].num == 3 && seq == 1){
        (member->before)->situa = 3;
    }
    if(discard[discard_position].num == 7 && seq == 0){
        (member->next)->situa = 7;
    }
    if(discard[discard_position].num == 7 && seq == 1){
        (member->before)->situa = 7;
    }
    if(discard[discard_position].num == 11 && seq == 0){
        (member->next)->situa = 11;
    }
    if(discard[discard_position].num == 11 && seq == 1){
        (member->before)->situa = 11;
    }
    if(discard[discard_position].num == 12 && seq == 0){
        if((member->before)->situa != 12){
            (member->before)->situa = 12;
        }
        else{
            (member->before)->situa = 0;
        }
    }
    if(discard[discard_position].num == 12 && seq == 1){
        if((member->next)->situa != 12){
            (member->next)->situa = 12;
        }
        else{
            (member->next)->situa = 0;
        }
    }
    return discard_position;
}
