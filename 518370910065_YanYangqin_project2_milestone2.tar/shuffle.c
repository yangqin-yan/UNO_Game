//
// Created by Thinkpad on 2019/6/16.
//
#include <stdio.h>
#include <time.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "uno.h"

void shuffle(card deck[MAX_CARD],int num_deck){
    int i,seq,t;
    char str[10];
    //adjust number of each kind of card

    //shuffle the deck
    srand((unsigned int)time(NULL));
    for(i=0;i<CARD_NUM*num_deck;i++){
        //generate random numbers
        seq = floor(rand() % CARD_NUM);
        t = deck[seq].num;
        strcpy(str,deck[seq].kind);
        deck[seq].num = deck[i].num;
        strcpy(deck[seq].kind, deck[i].kind);
        deck[i].num = t;
        strcpy(deck[i].kind,str);
    }
}
