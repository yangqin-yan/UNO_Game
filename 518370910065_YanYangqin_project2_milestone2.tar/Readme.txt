Name: Yan Yangqin
ID: 528370910065

************
* Project 2 *
************
---UNO---

#Game Description
UNO is an ancient Spanish card game. At the beginning of this game, every participant receives the same number of cards from the deck. Then participants follow the rules to play the card. The person who plays all the cards from his or her hand first will win the game.

The card-playing rule: 
-The game round goes on counter clockwise.
-Players can only play the card which has the same number or the same suit. 
-Each player can only play at most one card at a time.
-If one player does not have the proper card to play, he or she should draw a card from the deck and then is the next player's turn.



#Program
This program simulates the game mode of UNO.

(To be continued)
