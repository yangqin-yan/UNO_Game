//
// Created by Thinkpad on 2019/6/25.
//
#include <stdio.h>
#include <time.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "uno.h"

int draw_card(create *member,int hand_position, \
card deck[MAX_CARD],int deck_position,card discard[MAX_CARD],int discard_position){
    card last_card;
    int num_deck;

    //draw
    member->hand[hand_position].num = deck[deck_position].num;
    strcpy(member->hand[hand_position].kind,deck[deck_position].kind);
    //printf("hand_position = %d\n",hand_position);
    deck_position++;

    //check whether the deck has cards
    if(strcmp(deck[deck_position].kind,"spade") != 0 && \
    strcmp(deck[deck_position].kind,"heart") != 0 && \
    strcmp(deck[deck_position].kind,"diamond") != 0 && \
    strcmp(deck[deck_position].kind,"club") != 0){
        last_card.num = deck[deck_position-1].num;
        strcpy(last_card.kind,deck[deck_position-1].kind);//last card
        num_deck = deck_position / CARD_NUM;
        for(int i=0;i<discard_position;i++){
            deck[i].num = discard[i].num;
            strcpy(deck[i].kind,discard[i].kind);
        }
        shuffle(deck,num_deck);
    }
    return deck_position;
}
