//
// Created by Thinkpad on 2019/6/23.
//
#include <stdio.h>
#include <time.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "uno.h"
#define JACK 11
#define QUEEN 12
#define KING 13
#define ACE 14

po round_uno(po p,card deck[MAX_CARD],create *member,card discard[],int seq){
    int hand_position,i,match,num;
    char str[10],c[10];
    match = 0;

    while(match == 0){

        //tips for players
        card_print(discard[p.discard_position]);
        //printf("\n-%s %d\n",discard[p.discard_position].kind,discard[p.discard_position].num);
        printf("-%s. It is your turn now, little brother.(press enter)\n",member->name);
        getchar();

        hand_position = 0;
        while(member->hand[hand_position].kind[0] == 's'||\
        member->hand[hand_position].kind[0] == 'h'|| \
        member->hand[hand_position].kind[0] == 'd'|| \
        member->hand[hand_position].kind[0] == 'c'){//hand card
            card_print(member->hand[hand_position]);
            //printf("-%s %d ",member->hand[hand_position].kind,\
            member->hand[hand_position].num);
            hand_position++;
        }
        //printf("j=%d\n",j);

        //judge situation
        //rank 2: next player draw 2 cards
        //rank 3: next player draw 3 cards
        //rank 7: cancel an attack
        //Queen: change round order
        //Jack: skip the next player
        if(member->situa == 2) {
            printf("\n***If none of the cards is valid to play, input 'NaN draw'***\n");
            printf("Which card to display:");
            scanf("%s %s", str, c);
            //read the input
            if (strcmp(c, "draw") == 0) { //draw a card
                p.deck_position = draw_card(member, hand_position, deck, \
                p.deck_position, discard, p.discard_position);
                p.deck_position = draw_card(member, hand_position, deck, \
                p.deck_position, discard, p.discard_position);//2 times
                break;
            }
            for(i=0;i<hand_position;i++){
                //printf("i=%d ",i);
                //printf("--%d\n",member[which].hand[i].num);
                if(member->hand[i].num == num && member->hand[i].kind[0] == str[0]){
                    if((num ==  7 || num == 2) && str[0] == discard[p.discard_position].kind[0]){
                        match = 1;
                        member->situa = 0;
                        p.discard_position = display(member,i,discard,p.discard_position,seq);
                        break;
                    }
                }
            }
        }
        else if(member->situa == 3){
            printf("\n***If none of the cards is valid to play, input 'NaN draw'***\n");
            printf("Which card to display:");
            scanf("%s %s", str, c);
            //read the input
            if (strcmp(c, "draw") == 0) { //draw a card
                p.deck_position = draw_card(member, hand_position, deck, \
                p.deck_position, discard, p.discard_position);
                p.deck_position = draw_card(member, hand_position, deck, \
                p.deck_position, discard, p.discard_position);
                p.deck_position = draw_card(member, hand_position, deck, \
                p.deck_position, discard, p.discard_position);//3 times
                break;
            }
            for(i=0;i<hand_position;i++){
                //printf("i=%d ",i);
                //printf("--%d\n",member[which].hand[i].num);
                if(member->hand[i].num == num && member->hand[i].kind[0] == str[0]){
                    if((num ==  7 || num == 3) && str[0] == discard[p.discard_position].kind[0]){
                        match = 1;
                        p.discard_position = display(member,i,discard,p.discard_position,seq);
                        break;
                    }
                }
            }
        }
        else if(member->situa == JACK){
            break;
        }
        else if(member->situa == QUEEN){
            member->situa = 12;
        }
        else{//default
            printf("\n***If none of the cards is valid to play, input 'NaN draw'***\n");
            printf("Which card to display:");
            scanf("%s %s",str,c);

            //read the input
            if(strcmp(c,"draw") == 0){ //draw a card
                p.deck_position = draw_card(member,hand_position,deck,\
            p.deck_position,discard,p.discard_position);
                for(int k=0;k<20;k++){
                    if(strcmp(member->hand[k].kind,"spade") !=0 && \
                strcmp(member->hand[k].kind,"heart") !=0 && \
                strcmp(member->hand[k].kind,"diamond") !=0 && \
                strcmp(member->hand[k].kind,"club") !=0 ){
                        break;
                    }
                    card_print(member->hand[k]);
                    //printf("-%s %d ",member->hand[k].kind,member->hand[k].num);
                }
                printf("\n");
                break;
            }
            else if(strcmp(c,"Jack") == 0)
                num = 11;
            else  if(strcmp(c,"Queen") == 0)
                num = 12;
            else  if(strcmp(c,"King") == 0)
                num = 13;
            else  if(strcmp(c,"Ace") == 0)
                num = 14;
            else if(strcmp(c,"10") == 0)
                num = 10;
            else{
                num = c[0]-'0';
            }
            //printf("num-%d\n",num);

            //judge whether the card can be played
            for(i=0;i<hand_position;i++){
                //printf("i=%d ",i);
                //printf("--%d\n",member[which].hand[i].num);
                if(member->hand[i].num == num && member->hand[i].kind[0] == str[0]){
                    if(num ==  discard[p.discard_position].num || \
                str[0] == discard[p.discard_position].kind[0]){
                        match = 1;
                        //display the card
                        //printf("%d",member[which].hand[i].num);
                        //printf("posi1 = %d\n",discard_position);
                        p.discard_position = display(member,i,discard,p.discard_position,seq);
                        //printf("posi2 = %d\n",discard_position);
                        /*for(int k=0;k<20;k++)
                            printf("-%s %d ",member[which].hand[k].kind,member[which].hand[k].num);
                            */
                        break;
                    }
                }
            }

            if(match == 0){

                printf("invalid display,please display again(press enter)\n");
                getchar();
                //display(which,member,i,discard,discard_position);
            }
            //match = 1;//adjustment
        }
        }

    return p;

}
