//
// Created by Thinkpad on 2019/6/16.
//

//define const
#define JACK 11
#define QUEEN 12
#define KING 13
#define ACE 14
#define MAX_CARD 500
#define MAX_HAND 20
#define CARD_NUM 52
#define MAX_MEMBER 10

//define structure of cards
typedef struct _card{
    char kind[10];
    int num;
}card;

typedef struct _player_structure{
    card hand[MAX_HAND];

}create;

//define functions
#ifndef PROJECT_2_UNO_H
#define PROJECT_2_UNO_H
//void player(int num_p);
void create_card(int num_deck,card deck[MAX_CARD]);
void shuffle(card deck[MAX_CARD], int num_deck);
int distribute(int num_player,int hand_card,card deck[MAX_CARD],create member[MAX_CARD]);
void display(int which,create member[MAX_MEMBER],int hand_position, \
card discard[MAX_CARD],int discard_position);
void round_uno(int position_deck,card deck[MAX_CARD],\
create member[MAX_CARD],card discard[MAX_CARD],int which,int discard_position);
void draw_card(int which,create member[MAX_MEMBER],int hand_position, \
card deck[MAX_CARD],int deck_position,card discard[MAX_CARD],int discard_position);
#endif //PROJECT_2_UNO_H
