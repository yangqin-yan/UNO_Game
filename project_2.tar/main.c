#include <stdio.h>
#include <time.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "uno.h"
#define JACK 11
#define QUEEN 12
#define KING 13
#define ACE 14



int main(int argc,char *argv[]) {
    //definition
    card deck[MAX_CARD],discard[MAX_CARD];
    create member[MAX_CARD];
    int num_deck = 0,hand_card = 0,num_player = 0;
    int i,j,t,deck_position,num_round = 0,which;
    int discard_position;

    printf("*******************\n"
           "*                 *\n"
           "* Welcome to UNO! *\n"
           "*                 *\n"
           "*******************\n");
    printf("\n");

    //command
    for(i=0;i<argc;++i){
        printf("%d\n", i);
        if(strcmp(argv[i],"-h") == 0){
            printf("-h|--help print this help message\n"
                   "--log filename write the logs in filename (default: onecard.log)\n"
                   "-n n|--player-number=n n players, n must be larger than 2 (default: 4)\n"
                   "-c c|--initial-cards=c deal c cards per player, c must be at least 2 (default: 5)\n"
                   "-d d|--decks=d use d decks 52 cards each, d must be at least 2 (default: 2)\n"
                   "-r r|--rounds=r play r rounds, r must be at least 1 (default: 1)\n"
                   "-a|--auto run in demo mode\n");
        }
        //if --log

        if(strcmp(argv[i],"-n") == 0){
            for(int a=0;a<sizeof(argv[i+1]);a++){
                num_deck = num_player * 10 + (argv[i+1][a] - '0');
            }
        }

        if(strcmp(argv[i],"-c") == 0){
            for(int a=0;a<sizeof(argv[i+1]);a++){
                hand_card = hand_card * 10 + (argv[i+1][a] - '0');
            }
        }

        if(strcmp(argv[i],"-d") == 0){
            for(int a=0;a<sizeof(argv[i+1]);a++){
                num_deck = num_deck * 10 + (argv[i+1][a] - '0');
            }
        }

        if(strcmp(argv[i],"-r") == 0){
            for(int a=0;a<sizeof(argv[i+1]);a++){
                num_round = num_round * 10 + (argv[i+1][a] - '0');
            }
        }

        //-a auto
    }
    //input
    //printf("Number of rounds:");
    //scanf("%d",&round);
    //printf("\n");
    //round = 1;

    //printf("Number of decks:");
    //scanf("%d",&num_deck);
    printf("3\n");

    //default
    if(num_player == 0)
        num_player = 2;
    if(num_deck == 0)
        num_deck = 2;
    if(num_round == 0)
        num_round = 1;
    if(hand_card == 0)
        hand_card = 5;

    which = 0;

   // printf("Number of cards in hands:");
   // scanf("%d",&hand_card);

   // printf("\n");

    //initialize
    create_card(num_deck,deck);
    shuffle(deck,num_deck);

    //distribute
    deck_position = distribute(num_player,hand_card, \
    deck,member);
    printf("deck position:%d\n",deck_position);
    //rounds
    strcpy(discard[0].kind,"spade");
    discard[0].num = 2;
    round_uno(deck_position,deck,member,discard,which,0);


   /* for(i=0;i<CARD_NUM*num_deck;i++){
        if(deck[i].num == JACK)
            printf("%s Jack  ",deck[i].kind);
        else if(deck[i].num == QUEEN)
            printf("%s Queen  ",deck[i].kind);
        else if(deck[i].num == KING)
            printf("%s King  ",deck[i].kind);
        else if(deck[i].num == ACE)
            printf("%s Ace  ",deck[i].kind);
        else
            printf("%s %d  ",deck[i].kind,deck[i].num);
    }*/


    return 0;
}