//
// Created by Thinkpad on 2019/6/23.
//
#include <stdio.h>
#include <time.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "uno.h"
#define JACK 11
#define QUEEN 12
#define KING 13
#define ACE 14


void round_uno(int deck_position,card deck[MAX_CARD],\
create member[MAX_CARD],card discard[MAX_CARD],int which,int discard_position){
    int hand_position,i,match,num;
    char str[10],c[10];
    match = 0;

    while(match == 0){
        //tips for players
        printf("-%s %d\n",discard[discard_position].kind,discard[discard_position].num);
        printf("-It is your turn now, little brother.\n");

        hand_position = 0;
        while(member[which].hand[hand_position].kind[0] == 's'||\
        member[which].hand[hand_position].kind[0] == 'h'|| \
        member[which].hand[hand_position].kind[0] == 'd'|| \
        member[which].hand[hand_position].kind[0] == 'c'){//hand card
            printf("-%s %d ",member[which].hand[hand_position].kind,\
            member[which].hand[hand_position].num);
            hand_position++;
        }
        //printf("j=%d\n",j);
        printf("***If none of the cards is valid to play, input 'NaN draw'***\n");
        printf("Which card to display:");
        scanf("%s %s",str,c);
        //read the input
        if(strcmp(c,"draw") == 0){ //draw a card
            draw_card(which,member,hand_position,deck,\
            deck_position,discard,discard_position);
            for(int k=0;k<20;k++)
                printf("-%s %d ",member[which].hand[k].kind,member[which].hand[k].num);
            break;
        }
        else if(strcmp(c,"Jack") == 0)
            num = 11;
        else  if(strcmp(c,"Queen") == 0)
            num = 12;
        else  if(strcmp(c,"King") == 0)
            num = 13;
        else  if(strcmp(c,"Ace") == 0)
            num = 14;
        else if(strcmp(c,"10") == 0)
            num = 10;
        else{
            num = c[0]-'0';
        }
        printf("num-%d\n",num);
        //judge whether the card can be played
        for(i=0;i<hand_position;i++){
            //printf("i=%d ",i);
            //printf("--%d\n",member[which].hand[i].num);
            if(member[which].hand[i].num == num && member[which].hand[i].kind[0] == str[0]){
                match = 1;
                //display the card
                //printf("%d",member[which].hand[i].num);
                display(which,member,i,discard,discard_position);
                /*for(int k=0;k<20;k++)
                    printf("-%s %d ",member[which].hand[k].kind,member[which].hand[k].num);
                    */
                break;
            }
        }

        if(match == 0){
            printf("invalid display,please display again\n");
            //display(which,member,i,discard,discard_position);
        }
        //match = 1;//adjustment
    }


}
