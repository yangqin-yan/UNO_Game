//
// Created by Thinkpad on 2019/6/23.
//
#include <stdio.h>
#include <time.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "uno.h"
#define JACK 11
#define QUEEN 12
#define KING 13
#define ACE 14


int distribute(int num_player,int hand_card,card deck[MAX_CARD],create member[MAX_HAND]){
    int i,j;
    for(i=0;i<hand_card;i++){
        for(j=0;j<num_player;j++){
            member[j].hand[i].num = deck[(i+1)*(j+1)-1].num;
            strcpy(member[j].hand[i].kind,deck[(i+1)*(j+1)-1].kind);
        }
    }
    return (i+1)*(j+1)-1;

}
