//
// Created by Thinkpad on 2019/6/24.
//
#include <stdio.h>
#include <time.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "uno.h"

void display(int which,create member[MAX_MEMBER],int hand_position, \
card discard[MAX_CARD],int discard_position){

    //play to the discard
    discard_position++;
    //printf("%d",hand_position);

    discard[discard_position].num = member[which].hand[hand_position].num;//bug
    strcpy(discard[discard_position].kind,member[which].hand[hand_position].kind);//bug
    //printf("1\n");
    printf("play: %s %d\n",discard[discard_position].kind,\
    discard[discard_position].num);

    //delete the card in hand
    for(int i=hand_position;i<MAX_HAND-1;i++){
        member[which].hand[i].num = member[which].hand[i+1].num;
        strcpy(member[which].hand[i].kind,member[which].hand[i+1].kind);
    }

    //judge the special effect of the card
    //rank 2: next player draw 2 cards
    //rank 3: next player draw 3 cards
    //rank 7: cancel an attack
    //Queen: change round order
    //Jack: skip the next player

}
